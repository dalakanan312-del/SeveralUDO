
from __future__ import annotations
from pathlib import Path
import json, uuid, datetime, zipfile, io, sqlite3, tempfile, shutil
import storage
import cloud_schema

ROOT=Path(__file__).resolve().parent
LEGACY_DB=ROOT/"decades.db"
LEGACY_SAVES_DIR=ROOT/"saves"
LEGACY_REGISTRY=ROOT/"saves.json"
SAVE_PACKAGE_EXTENSION=".decades-save"
STARTER_SEED=ROOT/"starter_seed.json.gz"

def _now():
    return datetime.datetime.now(datetime.timezone.utc)

def _schema_name():
    return "save_"+uuid.uuid4().hex[:16].lower()

def ensure_setup():
    with storage.raw_connect(use_direct=True) as con:
        cloud_schema.create_registry(con)
    return True

def list_saves():
    ensure_setup()
    with storage.raw_connect() as con:
        with con.cursor() as cur:
            cur.execute("""SELECT save_id,name,schema_name,created_at,updated_at,source_note
                           FROM public.decades_saves ORDER BY created_at,save_id""")
            cols=[d.name for d in cur.description]
            return [dict(zip(cols,r)) for r in cur.fetchall()]

def active_save_id():
    saves=list_saves()
    if not saves:
        return None
    cfg=storage.load_config()
    desired=cfg.get("active_save_id")
    ids={s["save_id"] for s in saves}
    if desired in ids:
        return desired
    storage.update_active_save(saves[0]["save_id"])
    return saves[0]["save_id"]

def get_save(save_id):
    if not save_id:return None
    for s in list_saves():
        if s["save_id"]==save_id:return s
    return None

def active_save():
    return get_save(active_save_id())

def set_active(save_id):
    if not get_save(save_id):
        raise ValueError("Save not found.")
    storage.update_active_save(save_id)

def _register(con,save_id,name,schema_name,source_note=None):
    with con.cursor() as cur:
        cur.execute("""INSERT INTO public.decades_saves(save_id,name,schema_name,source_note)
                       VALUES(%s,%s,%s,%s)""",(save_id,name,schema_name,source_note))
    con.commit()

def _set_search_path(con,schema_name):
    from psycopg import sql
    with con.cursor() as cur:
        cur.execute(sql.SQL("SET search_path TO {}, public").format(sql.Identifier(schema_name)))

def _copy_table_between_schemas(con,source_schema,dest_schema,table):
    from psycopg import sql
    with con.cursor() as cur:
        cur.execute(sql.SQL("INSERT INTO {}.{} SELECT * FROM {}.{}")
                    .format(sql.Identifier(dest_schema),sql.Identifier(table),
                            sql.Identifier(source_schema),sql.Identifier(table)))

def _sqlite_tables(path):
    con=sqlite3.connect(path)
    try:
        return {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    finally:
        con.close()

def _copy_sqlite_into_schema(sqlite_path,pg_con,schema_name,clear_first=True):
    from psycopg import sql
    src=sqlite3.connect(sqlite_path)
    src.row_factory=sqlite3.Row
    try:
        available={r[0] for r in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        _set_search_path(pg_con,schema_name)
        for table in cloud_schema.TABLES:
            if table not in available:
                continue
            cols=[r[1] for r in src.execute(f"PRAGMA table_info({table})")]
            if not cols:
                continue
            rows=src.execute(f"SELECT * FROM {table}").fetchall()
            with pg_con.cursor() as cur:
                if clear_first:
                    cur.execute(sql.SQL("DELETE FROM {}").format(sql.Identifier(table)))
                if rows:
                    q=sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(
                        sql.Identifier(table),
                        sql.SQL(",").join(map(sql.Identifier,cols)),
                        sql.SQL(",").join(sql.Placeholder()*len(cols))
                    )
                    cur.executemany(q,[tuple(r[c] for c in cols) for r in rows])
        pg_con.commit()
    finally:
        src.close()

def migrate_sqlite_file(sqlite_path,name=None,make_active=True,source_note="Migrated from SQLite"):
    sqlite_path=Path(sqlite_path)
    if not sqlite_path.exists():
        raise FileNotFoundError(sqlite_path)
    tables=_sqlite_tables(sqlite_path)
    if "settings" not in tables or "sims" not in tables:
        raise ValueError("That file does not look like a Decades Tracker database.")

    save_id="SAVE-"+uuid.uuid4().hex[:10].upper()
    schema_name=_schema_name()
    display_name=(name or sqlite_path.stem or "Migrated Save").strip()

    with storage.raw_connect(use_direct=True) as con:
        cloud_schema.create_registry(con)
        cloud_schema.create_save_schema(con,schema_name)
        _copy_sqlite_into_schema(sqlite_path,con,schema_name,clear_first=True)
        _register(con,save_id,display_name,schema_name,source_note)
    if make_active:
        storage.update_active_save(save_id)
    return get_save(save_id)

def _seed_blank_from_source(con,dest_schema,source_save=None):
    if source_save:
        src_schema=source_save["schema_name"]
        for table in ["settings","rules","events","roll_rule_eras","roll_rule_values","calendar_rows"]:
            _copy_table_between_schemas(con,src_schema,dest_schema,table)
        con.commit()
        return
    if STARTER_SEED.exists():
        import gzip
        with gzip.open(STARTER_SEED,"rt",encoding="utf-8") as f:
            seed=json.load(f)
        _set_search_path(con,dest_schema)
        from psycopg import sql
        for table in ["settings","rules","events","roll_rule_eras","roll_rule_values","calendar_rows"]:
            rows=seed.get(table,[])
            if not rows:
                continue
            cols=list(rows[0].keys())
            query=sql.SQL("INSERT INTO {} ({}) VALUES ({}) ON CONFLICT DO NOTHING").format(
                sql.Identifier(table),
                sql.SQL(",").join(map(sql.Identifier,cols)),
                sql.SQL(",").join(sql.Placeholder()*len(cols))
            )
            with con.cursor() as cur:
                cur.executemany(query,[tuple(row.get(c) for c in cols) for row in rows])
        con.commit()
        return
    if LEGACY_DB.exists():
        _copy_sqlite_into_schema(LEGACY_DB,con,dest_schema,clear_first=True)
        return
    if STARTER_SEED.exists():
        import gzip
        with gzip.open(STARTER_SEED,"rt",encoding="utf-8") as f:
            seed=json.load(f)
        _set_search_path(con,dest_schema)
        from psycopg import sql
        with con.cursor() as cur:
            for table in ["settings","rules","events","roll_rule_eras","roll_rule_values","calendar_rows"]:
                rows=seed.get(table,[])
                if not rows:
                    continue
                cols=list(rows[0].keys())
                q=sql.SQL("INSERT INTO {} ({}) VALUES ({}) ON CONFLICT DO NOTHING").format(
                    sql.Identifier(table),
                    sql.SQL(",").join(map(sql.Identifier,cols)),
                    sql.SQL(",").join(sql.Placeholder()*len(cols))
                )
                cur.executemany(q,[tuple(r.get(c) for c in cols) for r in rows])
        con.commit()

def create_blank(name,calendar_start_year=1200,current_year=None,challenge_day=1,source_save_id=None):
    save_id="SAVE-"+uuid.uuid4().hex[:10].upper()
    schema_name=_schema_name()
    source=get_save(source_save_id) if source_save_id else active_save()
    start=int(calendar_start_year)
    year=int(current_year if current_year is not None else start)
    day=max(1,min(4,int(challenge_day)))
    gd=(year-start)*4+day

    with storage.raw_connect(use_direct=True) as con:
        cloud_schema.create_registry(con)
        cloud_schema.create_save_schema(con,schema_name)
        _seed_blank_from_source(con,schema_name,source)

        _set_search_path(con,schema_name)
        # Clear gameplay but retain configuration/event definitions.
        with con.cursor() as cur:
            for table in ["sim_photos","sims","households","pregnancies","rolls","relationships","event_results","raw_import_rows"]:
                cur.execute(f"DELETE FROM {table}")

            # Rebase event Global Days so the absolute historical years remain the same.
            old_start=1200
            if source:
                _set_search_path(con,source["schema_name"])
                cur.execute("SELECT value FROM settings WHERE key='start_year'")
                rr=cur.fetchone()
                old_start=int(float(rr[0])) if rr and rr[0] not in (None,"") else 1200
                _set_search_path(con,schema_name)
            else:
                cur.execute("SELECT value FROM settings WHERE key='start_year'")
                rr=cur.fetchone()
                old_start=int(float(rr[0])) if rr and rr[0] not in (None,"") else 1200

            cur.execute("SELECT event_id,start_global_day,end_global_day FROM events")
            event_rows=cur.fetchall()
            def rebase(event_gd):
                if event_gd is None:return None
                eg=int(event_gd)
                abs_year=old_start+(eg-1)//4
                quarter=((eg-1)%4)+1
                return (abs_year-start)*4+quarter
            for eid,sg,eg in event_rows:
                cur.execute("UPDATE events SET start_global_day=%s,end_global_day=%s WHERE event_id=%s",
                            (rebase(sg),rebase(eg),eid))

            settings={
                "start_year":start,"days_per_year":4,"current_global_day":gd,
                "current_heir_id":"","main_household_id":""
            }
            for k,v in settings.items():
                cur.execute("""INSERT INTO settings(key,value) VALUES(%s,%s)
                               ON CONFLICT(key) DO UPDATE SET value=excluded.value""",(k,str(v)))
        con.commit()
        _register(con,save_id,name.strip() or "New Save",schema_name,"Created in Neon")
    storage.update_active_save(save_id)
    return get_save(save_id)

def duplicate_save(source_save_id,name):
    source=get_save(source_save_id)
    if not source:raise ValueError("Save not found.")
    save_id="SAVE-"+uuid.uuid4().hex[:10].upper()
    schema_name=_schema_name()
    with storage.raw_connect(use_direct=True) as con:
        cloud_schema.create_save_schema(con,schema_name)
        for table in cloud_schema.TABLES:
            _copy_table_between_schemas(con,source["schema_name"],schema_name,table)
        con.commit()
        _register(con,save_id,name.strip() or f"{source['name']} Copy",schema_name,"Cloud duplicate")
    storage.update_active_save(save_id)
    return get_save(save_id)

def rename_save(save_id,new_name):
    with storage.raw_connect() as con:
        with con.cursor() as cur:
            cur.execute("""UPDATE public.decades_saves SET name=%s,updated_at=now()
                           WHERE save_id=%s""",(new_name.strip(),save_id))
        con.commit()
    return get_save(save_id)

def delete_save(save_id):
    saves=list_saves()
    if len(saves)<=1:raise ValueError("You cannot delete the only save.")
    rec=get_save(save_id)
    if not rec:raise ValueError("Save not found.")
    from psycopg import sql
    with storage.raw_connect(use_direct=True) as con:
        with con.cursor() as cur:
            cur.execute(sql.SQL("DROP SCHEMA {} CASCADE").format(sql.Identifier(rec["schema_name"])))
            cur.execute("DELETE FROM public.decades_saves WHERE save_id=%s",(save_id,))
        con.commit()
    if active_save_id()==save_id:
        remaining=list_saves()
        if remaining:storage.update_active_save(remaining[0]["save_id"])

def touch_active():
    sid=active_save_id()
    if not sid:return
    with storage.raw_connect() as con:
        with con.cursor() as cur:
            cur.execute("UPDATE public.decades_saves SET updated_at=now() WHERE save_id=%s",(sid,))
        con.commit()

def _sqlite_ddl(ddl):
    return ddl.replace("BYTEA","BLOB").replace("DOUBLE PRECISION","REAL")

def export_save_package(save_id):
    rec=get_save(save_id)
    if not rec:raise ValueError("Save not found.")
    with tempfile.TemporaryDirectory() as td:
        db_path=Path(td)/"save.db"
        sq=sqlite3.connect(db_path)
        try:
            for ddl in cloud_schema.TABLE_DDLS:
                sq.execute(_sqlite_ddl(ddl))
            with storage.raw_connect() as con:
                _set_search_path(con,rec["schema_name"])
                for table in cloud_schema.TABLES:
                    with con.cursor() as cur:
                        cur.execute(f"SELECT * FROM {table}")
                        if not cur.description:continue
                        cols=[d.name for d in cur.description]
                        rows=cur.fetchall()
                    if rows:
                        ph=",".join("?" for _ in cols)
                        sq.executemany(
                            f"INSERT INTO {table} ({','.join(cols)}) VALUES ({ph})",
                            rows
                        )
            sq.commit()
        finally:
            sq.close()
        manifest={
            "format":"Decades Tracker Save",
            "format_version":2,
            "storage":"portable-sqlite",
            "save_name":rec["name"],
            "exported_at":_now().isoformat(),
            "database_file":"save.db",
        }
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
            z.writestr("manifest.json",json.dumps(manifest,indent=2))
            z.write(db_path,"save.db")
        return buf.getvalue()

def import_save_package(data,preferred_name=None,make_active=True):
    with tempfile.TemporaryDirectory() as td:
        path=Path(td)/"incoming.db"
        bio=io.BytesIO(data)
        name=preferred_name
        if zipfile.is_zipfile(bio):
            bio.seek(0)
            with zipfile.ZipFile(bio) as z:
                if "save.db" not in z.namelist():
                    raise ValueError("This archive does not contain a Decades Tracker save.")
                path.write_bytes(z.read("save.db"))
                if not name and "manifest.json" in z.namelist():
                    try:name=json.loads(z.read("manifest.json")) .get("save_name")
                    except Exception:pass
        else:
            path.write_bytes(data)
        return migrate_sqlite_file(path,name or "Imported Save",make_active,"Imported .decades-save")

def discover_local_saves():
    """Find legacy SQLite saves beside the upgraded app without modifying them."""
    found=[]
    names={}
    if LEGACY_REGISTRY.exists():
        try:
            reg=json.loads(LEGACY_REGISTRY.read_text(encoding="utf-8"))
            for s in reg.get("saves",[]):
                p=Path(s.get("db_path",""))
                if not p.is_absolute():
                    p=ROOT/p
                names[str(p.resolve())]=s.get("name")
        except Exception:
            pass
    candidates=[]
    save_dir_candidates=sorted(LEGACY_SAVES_DIR.glob("*.db")) if LEGACY_SAVES_DIR.exists() else []
    # In multi-save v1.x installs, root decades.db is only a legacy safety copy.
    # Prefer the databases in saves/ so the same world isn't offered twice.
    if save_dir_candidates:
        candidates.extend(save_dir_candidates)
    elif LEGACY_DB.exists():
        candidates.append(LEGACY_DB)
    seen=set()
    for p in candidates:
        rp=str(p.resolve())
        if rp in seen:continue
        seen.add(rp)
        try:
            con=sqlite3.connect(p)
            tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {"settings","sims"}.issubset(tables):
                con.close();continue
            sim_count=con.execute("SELECT COUNT(*) FROM sims").fetchone()[0]
            gdrow=con.execute("SELECT value FROM settings WHERE key='current_global_day'").fetchone()
            syrow=con.execute("SELECT value FROM settings WHERE key='start_year'").fetchone()
            con.close()
            found.append({
                "path":str(p),
                "name":names.get(rp) or ("Original Save" if p==LEGACY_DB else p.stem),
                "sims":sim_count,
                "current_global_day":gdrow[0] if gdrow else None,
                "start_year":syrow[0] if syrow else None,
            })
        except Exception:
            continue
    return found


def save_summary(save_id):
    rec=get_save(save_id)
    if not rec:return {}
    with storage.raw_connect() as con:
        _set_search_path(con,rec["schema_name"])
        with con.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM sims")
            sims=cur.fetchone()[0]
            cur.execute("SELECT key,value FROM settings WHERE key IN ('start_year','days_per_year','current_global_day')")
            vals=dict(cur.fetchall())
    start=int(float(vals.get("start_year",1200)))
    dpy=int(float(vals.get("days_per_year",4)))
    gd=int(float(vals.get("current_global_day",1)))
    year=start+(gd-1)//dpy
    return {"sims":sims,"start_year":start,"days_per_year":dpy,"current_global_day":gd,"historical_year":year}
